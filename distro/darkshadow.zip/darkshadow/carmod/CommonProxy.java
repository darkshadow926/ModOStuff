package darkshadow.carmod;


public class CommonProxy {
    // Client stuff
    public void registerRenderers() {
            // Nothing here as the server doesn't render graphics!
    }
}