package darkshadow.carmod.client;


import net.minecraftforge.client.MinecraftForgeClient;
import darkshadow.carmod.CommonProxy;

public class ClientProxy extends CommonProxy {
        
        
}