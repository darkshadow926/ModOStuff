package darkshadow.carmod;

import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.block.material.Material;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.common.MinecraftForge;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.Init;
import cpw.mods.fml.common.Mod.Instance;
import cpw.mods.fml.common.Mod.PostInit;
import cpw.mods.fml.common.Mod.PreInit;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.network.NetworkMod;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.common.registry.LanguageRegistry;

@Mod(modid="CarMod", name="DarkShadow's Car Mod", version="0.0")
@NetworkMod(clientSideRequired=true, serverSideRequired=false)


public class CarMod {

	public final static Block Ostuff = 
			new BlockOstuff(254, Material.rock)
				.setHardness(1.5F)
				.setResistance(10.0F)
				.setLightValue(0.5F)
				.setCreativeTab(CreativeTabs.tabBlock)
				.setUnlocalizedName("Ostuff")
				.func_111022_d("carmod:Ostuff");
	
	// The instance of your mod that Forge uses.
	@Instance("CarMod")
	public static CarMod instance;

	// Says where the client and server 'proxy' code is loaded.
	@SidedProxy(clientSide="darkshadow.carmod.client.ClientProxy", serverSide="darkshadow.carmod.CommonProxy")
	public static CommonProxy proxy;

	@PreInit
	public void preInit(FMLPreInitializationEvent event) {
		// Stub Method
	}

	@Init
	public void load(FMLInitializationEvent event) {

		// Basic Blocks
		LanguageRegistry.addName(Ostuff, "Block O'Stuff");
		// MinecraftForge.setBlockHarvestLevel(Ostuff, "shovel", 0);
		GameRegistry.registerBlock(Ostuff, "Ostuff");
		// End Basic Blocks
		
		GameRegistry.registerWorldGenerator(new CarModWorldGenerator());

		proxy.registerRenderers();
	}
	
	
	@PostInit
	public void postInit(FMLPostInitializationEvent event) {
		// Stub Method
	}
}
